import AIWorkbenchApp from "@/polymet/prototypes/ai-workbench-app"

export default function AIWorkbenchAppRender() {
  return <AIWorkbenchApp />
}